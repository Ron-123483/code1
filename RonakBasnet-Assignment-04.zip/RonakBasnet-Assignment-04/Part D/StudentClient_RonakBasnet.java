/**
 * Please implement class StudentClient by adding code to it.
 * Please DO NOT change the provided code. ONLY add more code.
 * <p>
 * Class:       StudentClient
 * File Name:   StudentClient.java
 *
 * @author Ronak basnet
 * <p>
 * <p>
 * /**
 * *File: [StudentClient_RonakBasnet].
 * * By: [Ronak Basnet]
 * * Date: [3/9/2024]
 * * Description: [This program prints the object-oriented code]
 * *
 */

package asmt05;

import java.util.Scanner;

public class StudentClient_RonakBasnet {


    public static void userInput() {

        Scanner input = new Scanner(System.in);
        System.out.println("[+] Creating 3 students... ");
        System.out.print(" - Enter a name for student #1: ");
        String studentName = input.nextLine();
        System.out.print(" - Enter a GPA for student #1:  ");
        double studentGpa = input.nextDouble();
        Student studentObjectOne = new Student(studentName, studentGpa);


        System.out.println();

        System.out.print(" - Enter a name for student #2: ");
        input.nextLine();
        String studentTwoName = input.nextLine();

        System.out.print(" - Enter a GPA for student #2:  ");
        double studentTwoGpa = input.nextDouble();
        Student studentObjectTwo = new Student(studentTwoName, studentTwoGpa);

        System.out.println();

        System.out.print(" - Enter a name for student #3: ");
        input.nextLine();
        String studentThreeName = input.nextLine();

        System.out.print(" - Enter a GPA for student #3:  ");
        double studentThreeGpa = input.nextDouble();
        Student studentObjectThree = new Student(studentThreeName, studentThreeGpa);

        System.out.println("\n[+] The 3 students created: ");

        System.out.println(studentObjectOne.toString());
        System.out.println(studentObjectTwo.toString());
        System.out.println(studentObjectThree.toString());


        System.out.print("\n[-] Enter a student's full name to update the student: ");
        input.nextLine();
        String oldName = input.nextLine();
        System.out.print("[-] Enter new student name:  ");
        String newStudentName = input.nextLine();
        System.out.print("[-] Enter new student gpa:   ");
        double newStudentGpa = input.nextDouble();
        System.out.println();
        System.out.println("[+] The 3 students updated: ");


        if (studentObjectOne.getName().equalsIgnoreCase(oldName)) {
            studentObjectOne.setName(newStudentName);
            studentObjectOne.setGpa(newStudentGpa);
        } else if (studentObjectTwo.getName().equalsIgnoreCase(oldName)) {
            studentObjectTwo.setName(newStudentName);
            studentObjectTwo.setGpa(newStudentGpa);
        } else if (studentObjectThree.getName().equalsIgnoreCase(oldName)) {
            studentObjectThree.setName(newStudentName);
            studentObjectThree.setGpa(newStudentGpa);
        } else {
            System.out.println("This name does not exist");
        }


        System.out.println(studentObjectOne.toString());
        System.out.println(studentObjectTwo.toString());
        System.out.println(studentObjectThree.toString());


        System.out.println();

    }


    public static void main(String[] args) {

        userInput();


    }
}











