 /**
 * *File: [DegreePlanner_3DArray_RonakBasnet].
 * * By: [Ronak Basnet]
 * * Date: [3/20/2024]
 * * Description: [This program prints the 3d array]
 * *
 */

 import java.util.Arrays;

public class DegreePlanner_3DArray_RonakBasnet {


    public static void intro() {
        System.out.println("Printing data... from one 3D String[4][3][2] array containing 24 items: ");


        String[][][] arr = new String[][][]
                {{{"csc101", "csc102", "csc103", "csc104", "csc105", "csc106"}},
                        {{"csc201", "csc202", "csc203", "csc204", "csc205", "csc206"}},
                        {{"csc301", "csc302", "csc303", "csc304", "csc305", "csc306"}},
                        {{"csc401", "csc402", "csc403", "csc404", "csc405", "csc406"}}};

        body(arr);
    }


    public static void body(String arr[][][]) {


        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                for (int k = 0; k < arr[i][j].length; k++) {
                    if (arr[i][j][k].equals("csc101")) {
                        System.out.print(" - Semester #1: ");
                    } else if (arr[i][j][k].equals("csc201")) {
                        System.out.print(" - Semester #2: ");
                    } else if (arr[i][j][k].equals("csc301")) {
                        System.out.print(" - Semester #3: ");
                    } else if (arr[i][j][k].equals("csc401")) {
                        System.out.print(" - Semester #4: ");
                    }

                    if (arr[i][j][k].equals("csc102") || arr[i][j][k].equals("csc103") || arr[i][j][k].equals("csc104") || arr[i][j][k].equals("csc105") || arr[i][j][k].equals("csc106")) {
                        System.out.print(", ");
                    } else if (arr[i][j][k].equals("csc202") || arr[i][j][k].equals("csc203") || arr[i][j][k].equals("csc204") || arr[i][j][k].equals("csc205") || arr[i][j][k].equals("csc206")) {
                        System.out.print(", ");
                    } else if (arr[i][j][k].equals("csc302") || arr[i][j][k].equals("csc303") || arr[i][j][k].equals("csc304") || arr[i][j][k].equals("csc305") || arr[i][j][k].equals("csc306")) {
                        System.out.print(", ");
                    } else if (arr[i][j][k].equals("csc402") || arr[i][j][k].equals("csc403") || arr[i][j][k].equals("csc404") || arr[i][j][k].equals("csc405") || arr[i][j][k].equals("csc406")) {
                        System.out.print(", ");
                    }
                    System.out.print(arr[i][j][k]);

                }

                System.out.println();
            }


        }

    }

    public static void main(String[] args) {
        intro();


    }

}







