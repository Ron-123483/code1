/**
 * *File: [DegreePlanner_3DArray_RonakBasnet].
 * * By: [Ronak Basnet]
 * * Date: [3/20/2024]
 * * Description: [This program prints the 3d array]
 * *
 */

public class DegreePlanner_OOP_RonakBasnet {

    static class Semester{
        String[] semester01 = {"csc101", "csc102", "csc103", "csc104", "csc105", "csc106"};
        String[] semester02 = {"csc201", "csc202", "csc203", "csc204", "csc205", "csc206"};
        String[] semester03 = {"csc301", "csc302", "csc303", "csc304", "csc305", "csc306"};
        String[] semester04 = {"csc401", "csc402", "csc403", "csc404", "csc405", "csc406"};

    }

    public static void intro(){
        System.out.println("Printing data... from one 1D String[] array containing 4 items:");
    }
    public static void body(){
        //just created a for experiment
        Semester a = new Semester();
        Semester b = new Semester();
        output(a, b);
    }

    private static void output(Semester a, Semester b) {


        String[] arr = new String[4];

        System.out.print(" - Semester #1: ");
        for (int i = 0; i < b.semester01.length; i++) {
            System.out.print(b.semester01[i]);
            if (b.semester01[i].equals("csc101") || b.semester01[i].equals("csc102") || b.semester01[i].equals("csc103") || b.semester01[i].equals("csc104") || b.semester01[i].equals("csc105")) {
                System.out.print(", ");
            }
        }
        System.out.println();
        System.out.print(" - Semester #2: ");
        for (int i = 0; i < a.semester02.length; i++) {
                System.out.print(a.semester02[i]);
                if (a.semester02[i].equals("csc201") || a.semester02[i].equals("csc202") || a.semester02[i].equals("csc203") || a.semester02[i].equals("csc204") || a.semester02[i].equals("csc205")) {
                    System.out.print(", ");
                }
            }
        System.out.println();
        System.out.print(" - Semester #3: ");
        for (int i = 0; i < b.semester03.length; i++) {
            System.out.print(b.semester03[i]);
            if (b.semester03[i].equals("csc301") || b.semester03[i].equals("csc302") || b.semester03[i].equals("csc303") || b.semester03[i].equals("csc304") || b.semester03[i].equals("csc305")) {
                System.out.print(", ");
            }
        }
        System.out.println();
        System.out.print(" - Semester #4: ");
        for (int i = 0; i < b.semester04.length; i++) {
            System.out.print(b.semester04[i]);
            if (b.semester04[i].equals("csc401") || b.semester04[i].equals("csc402") || b.semester04[i].equals("csc403") || b.semester04[i].equals("csc404") || b.semester04[i].equals("csc405")) {
                System.out.print(", ");
            }
        }

}

    public static void main(String[]args){

        intro();
        body();

    }

}



